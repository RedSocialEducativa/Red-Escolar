<?php

	Class Notas{
		private $id;
		private $nombre;
		private $parcial;
		private $final;
		private $mejoramiento;
		

		function __construct($id, $nombre, $parcial, $final, $mejoramiento) {
	       $this->id = $id;
	       $this->nombre = $nombre;
 	       $this->parcial = $parcial;
	       $this->$final = $final;
	       $this->mejoramiento= $mejoramiento;
	      
	       
     	}
     	
		function getId(){
		return $this->id;
		}

		function getNombre(){
		return $this->nombre;
		}

		function getParcial(){
		return $this->parcial;
		}

		function getFinal(){
		return $this->$final;
		}

		function getMejoramiento(){
		return $this->mejoramiento;
		}


		


//		Set
		function setId($id){
			$this->id = $id;
		}

		function setNombre($nombre){
			$this->nombre = $nombre;
		}

		function setParcial($parcial){
			$this->parcial = $parcial;
		}

		function setFinal($final){
			$this->$final = $final;
		}

		function setMejoramiento($mejoramiento){
			$this->mejoramiento = $mejoramiento;
		}

		
		

	}// Cierre de Clase

?>
