<?php
include_once("NotasCollector.php");

$id =1;


$NotasCollectorObj = new NotasCollector();

foreach ($NotasCollectorObj->showNotas() as $c){




   echo "<div>";
  echo "ID:".$c->getId()."<br>";
  echo "Nombre: ".$c->getNombre()."<br>";
   echo "Parcial: ".$c->getParcial()."<br>";
    echo "Final: ".$c->getFinal()."<br>";
   echo "Mejoramiento: ".$c->getMejoramiento()."<br>";
   
	 echo "</div>"; 
  
}


?>
