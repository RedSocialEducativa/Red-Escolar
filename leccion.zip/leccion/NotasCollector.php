<?php

include_once('notas.php');
include_once('Collector.php');

class NotasCollector extends Collector
{
  
  function showNotas() {
    $rows = self::$db->getRows("SELECT * FROM Notas");        
    $arrayNotas= array(); 
   	   
    foreach ($rows as $c){
      $aux = new notas($c{'id'},$c{'nombre'},$c{'parcial'},$c{'final'},$c{'mejoramiento'});
      array_push($arrayNotas, $aux);
    }
    return $arrayNotas;        
  }

}
?>

