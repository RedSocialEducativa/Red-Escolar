<?php
include_once("UsuarioCollector.php");

$id =1;


$UsuarioCollectorObj = new UsuarioCollector();

foreach ($UsuarioCollectorObj->showUsuario() as $c){
  echo "<div>";
  echo $c->getId() . " Correo:  " .$c->getCorreoElectronico() . " Contrase&ntilde;a:  " .$c->getPassword();                                     
  echo "</div>"; 
}


?>
