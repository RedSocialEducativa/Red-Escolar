<?php
include_once("GrupoCollector.php");

$id =1;


$GrupoCollectorObj = new GrupoCollector();

foreach ($GrupoCollectorObj->showGrupo() as $c){
  echo "<div>";
  echo $c->getId() . "   " .$c->getNombre() . "   " .$c->getDescripcion();                                     
  echo "</div>"; 
}


?>
